HeroMetal CRM Android v28

این پروژه آماده ساخت APK است.

ساده‌ترین روش:
1- پروژه را در GitHub قرار دهید.
2- Actions را باز کنید.
3- Build HeroMetal CRM APK را انتخاب کنید.
4- Run workflow را بزنید.
5- پس از پایان کار، Artifact با نام HeroMetal-CRM-v28-debug را دانلود کنید.
6- داخل آن فایل app-debug.apk قرار دارد و همان فایل قابل نصب روی گوشی است.

برای نصب APK روی گوشی:
- فایل APK را به گوشی منتقل کنید.
- روی فایل بزنید.
- اگر Android اجازه نصب از این منبع را خواست، اجازه نصب را فعال کنید.

حداقل Android: 6.0 (API 23)
هدف: Android 15 (API 35)
