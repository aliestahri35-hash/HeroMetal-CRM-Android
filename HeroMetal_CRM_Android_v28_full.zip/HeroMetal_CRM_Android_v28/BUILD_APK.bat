@echo off
chcp 65001 >nul
setlocal

echo ================================================
echo   HeroMetal CRM v28 - Android APK Builder
echo ================================================
echo.

gradle --version >nul 2>&1
if errorlevel 1 (
  echo Gradle پيدا نشد.
  echo اگر Android Studio نصب است، پروژه را از داخل Android Studio باز کنيد.
  echo راهنما: BUILD_APK_WINDOWS.md
  pause
  exit /b 1
)

gradle :app:assembleDebug --no-daemon
if errorlevel 1 (
  echo.
  echo Build با خطا متوقف شد.
  pause
  exit /b 1
)

echo.
echo APK ساخته شد:
echo app\build\outputs\apk\debug\app-debug.apk
pause
