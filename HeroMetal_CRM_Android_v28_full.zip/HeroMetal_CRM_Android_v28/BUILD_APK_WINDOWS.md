# ساخت APK در ویندوز

## روش ۱ — بدون نصب Android Studio

ساده‌ترین روش برای ساخت APK استفاده از GitHub Actions است.

1. یک Repository خصوصی یا عمومی در GitHub بسازید.
2. تمام فایل‌های این پروژه را داخل Repository آپلود کنید.
3. از منوی **Actions**، گردش‌کار **Build HeroMetal CRM APK** را انتخاب کنید.
4. روی **Run workflow** بزنید.
5. پس از پایان Build، در بخش **Artifacts** فایل `HeroMetal-CRM-v28-debug` را دانلود کنید.
6. فایل `app-debug.apk` را روی گوشی کپی و نصب کنید.

## روش ۲ — Android Studio

پروژه را با Android Studio باز کنید و از مسیر:

`Build > Build Bundle(s) / APK(s) > Build APK(s)`

APK در این مسیر ساخته می‌شود:

`app/build/outputs/apk/debug/app-debug.apk`

حداقل نسخه Android: **Android 6.0 / API 23**

نسخه هدف: **Android 15 / API 35**
